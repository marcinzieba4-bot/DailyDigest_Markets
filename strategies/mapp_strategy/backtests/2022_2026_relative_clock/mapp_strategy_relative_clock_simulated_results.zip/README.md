# mapp_strategy: relative-strength gate and fill-only reservation

Four predeclared variants are compared on one coherent source/price campaign: absolute_reserved (existing control), absolute_filled (clock change), relative_reserved (gate change), relative_filled (both changes). Each is simulated with the three unchanged hedge policies.

All use Part 4 only, the frozen stock-to-ETF mapping, 25% source allocation, 10-session maximum holding clock (21 calendar-day cap), 10 bp per net physical order, 3% ACT365 net-short borrow and zero cash yield. Rejected original target weights remain cash.

Relative strength is the adjusted ETF/SPY ratio, measured strictly before entry: the last completed ratio must be above its previous-20-close average for longs and below it for shorts. SPY/SPY is constant and fails either strict inequality. This is a replacement for the absolute gate, not an additional filter.

Fill-only reservation consumes a rejected report without starting a reservation or cooldown. The next new report may qualify. A funded trade retains its ordinary time exit, release-day exclusion and full following-session cooldown. Reserved variants consume the full window after rejection.

## Net results

| Policy | Variant | Net return | Max drawdown | Baskets | Realized all-day SPY beta |

|---|---|---:|---:|---:|---:|

| No SPY hedge | absolute_reserved | +19.05% | -3.55% | 55 | 0.064 |

| No SPY hedge | absolute_filled | +13.55% | -8.56% | 71 | 0.112 |

| No SPY hedge | relative_reserved | +18.71% | -3.55% | 44 | 0.066 |

| No SPY hedge | relative_filled | +1.06% | -9.32% | 71 | 0.152 |

| Fixed-dollar SPY short | absolute_reserved | +2.64% | -9.05% | 55 | -0.006 |

| Fixed-dollar SPY short | absolute_filled | -3.86% | -10.78% | 71 | -0.002 |

| Fixed-dollar SPY short | relative_reserved | +4.41% | -6.83% | 44 | -0.003 |

| Fixed-dollar SPY short | relative_filled | -10.20% | -12.48% | 71 | -0.003 |

| Daily beta40 SPY short or flat | absolute_reserved | -3.45% | -11.00% | 55 | -0.005 |

| Daily beta40 SPY short or flat | absolute_filled | -7.02% | -9.69% | 71 | -0.006 |

| Daily beta40 SPY short or flat | relative_reserved | -1.32% | -7.87% | 44 | -0.005 |

| Daily beta40 SPY short or flat | relative_filled | -9.55% | -11.94% | 71 | -0.008 |


![Daily-close PnL for all twelve accounts](figures/mapp_strategy_relative_clock_pnl.png)

Hedges never buy SPY. Dollar neutrality and beta neutrality differ; source shorts or negative-beta sources can leave exposure that a short-only hedge cannot remove. The metrics report all-day and active-day realized beta and short-only constraints.

Annual returns are calendar returns. Entry-cohort and instrument diagnostics are attribution on the actual compounded account, not new backtests with 2026 or XLE removed. Source-leg instrument PnL excludes arbitrary allocation of account-level hedge PnL and costs.

Missing months create no new entries; normal exits and hedges continue. Source reports are current reconstructed snapshots with assumed printed-date historical availability. Comparison to an earlier saved control is reported separately; a new price/source vintage is not silently treated as identical.

There is no RSI, weekly filter, new stop-loss, added macro-regime filter or parameter search. The reports, raw prices and extracted prose remain local. Published data are code, simulated trades/orders/NAV and audit metadata.

Entry attempts and qualification CSVs retain rejected-candidate dates, mapped targets, gate inputs and reasons without report prose. A scheduled exit on an unfunded fill-only attempt is hypothetical; actually_reserved distinguishes it from a real lockout.

[All trades](all_trades.csv) · [All orders](all_orders.csv) · [Metrics](metrics.csv) · [Calendar returns](calendar_year_returns.csv) · [Concentration](concentration.json) · [Entry attempts](entry_attempts.csv) · [Qualification](entry_qualification.csv)
