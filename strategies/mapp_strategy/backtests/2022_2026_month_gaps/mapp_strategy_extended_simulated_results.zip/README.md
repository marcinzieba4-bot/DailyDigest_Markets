# mapp_strategy extended-history simulation

Only the fourth topic of What Retail Is Playing is mapped into the frozen ETF universe. This study preserves the existing 25% allocation, previous-close SMA20 trend gate, 10-session reservation/holding clock and complete flat-session cooldown. Three accounts compare no SPY hedge, an entry-fixed SPY short, and a daily 40-return beta SPY short or flat. Hedges never buy SPY. Source trades may include SPY and may be short when the report mapping says so.

A pre-outcome parsing correction recognizes the complete GC=F gold-futures identity as GLD, and rejects other unsupported complete =F futures identities so their F suffix is never read as Ford. The frozen 153-stock sector dictionary and economic engine remain unchanged.

A month absent from the available public report inventory creates no new entries during that month. Positions already open retain their normal exits. The account continues across all US sessions. The coverage file lists missing months and partial-month/date coverage separately.

Accounts start with $100,000, flat. PnL is net of 10 bp on net physical orders and 3% ACT365 short borrow. There is no RSI/weekly filter, stop-loss, optimization or added regime filter.

Reports are current reconstructed archive snapshots. Availability at printed date 23:59:59 New York is assumed for counterfactual replay and is not evidence of contemporaneous availability. Terminal liquidations, if any, are flagged as censored.

This archive contains code-independent accounting diagnostics and simulated results only. Raw reports, extracted report prose and price downloads remain on the ephemeral execution runner. The public input-freeze file contains hashes only; the audit/input receipt contains aggregate validation checks.

Per-policy results CSVs use normalized initial NAV 1. Consolidated USD columns are explicitly suffixed _usd, and order quantities scaled to the $100,000 account are explicitly labeled in their column names.
